package main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import beans.Test;

public class Client {
	
	public static void main(String[] args) {
		
		// find the xml file
	 Resource rs = new ClassPathResource("resources/springconfig.xml");	
		
	 // load and create the instance
     BeanFactory facorty = new XmlBeanFactory(rs);
		
     Test bean = (Test)facorty.getBean("eid");
     bean.hello();
		
		
		
	}

}
