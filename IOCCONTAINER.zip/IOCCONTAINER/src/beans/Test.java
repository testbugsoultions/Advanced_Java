package beans;

public class Test {
	
	public void hello() {
		
		System.out.println("Hello World Testbug");
		
	}

}
