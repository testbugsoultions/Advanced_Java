package com.testbug;


//depedency
public class Homeneedss {

	public void foods() {

		System.out.println("This is sunflower oil");

	}

}
