package com.testbug;

public class AmazonController {
	
	private Electronic ec;
	private Cloths cc;
	private Homeneedss hn;
	
//	public AmazonController(Electronic ec, Cloths cc, Homeneedss hn) {
//		super();
//		this.ec = ec;
//		this.cc = cc;
//		this.hn = hn;
//	}
	
	public AmazonController() {
		// TODO Auto-generated constructor stub
	}
	
	public Electronic getEc() {
		return ec;
	}


	public void setEc(Electronic ec) {
		this.ec = ec;
	}

	public Cloths getCc() {
		return cc;
	}

	public void setCc(Cloths cc) {
		this.cc = cc;
	}

	public Homeneedss getHn() {
		return hn;
	}

	public void setHn(Homeneedss hn) {
		this.hn = hn;
	}

	
	public void display() {
		System.out.println("Purchaged by Amazon productes");
		ec.laptop();
		cc.shirts();
		hn.foods();
		
		// need the Aop jar file [add the classpath into jar]
		
	}
	
	

}
