package com.testbug;


//depedency
public class Cloths {
	
public void shirts() {
		
		System.out.println("This is Allensolly");
		
	}
	

}
