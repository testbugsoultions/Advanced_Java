package com.testbug;

// depedency
public class Electronic {
	
	public void laptop() {
		
		System.out.println("This is Samsung laptop");
		
	}
	
	

}
