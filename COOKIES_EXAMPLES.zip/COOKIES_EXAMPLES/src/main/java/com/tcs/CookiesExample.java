package com.tcs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookiesExample extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String fname = request.getParameter("firstName");
		String lname = request.getParameter("lastName");
		String addr = request.getParameter("address");
		
		Cookie ck1 = new Cookie("fname", fname);
		Cookie ck2 = new Cookie("lname", lname);
		Cookie ck3 = new Cookie("addr", addr);
		
		response.addCookie(ck1);
		response.addCookie(ck2);
		response.addCookie(ck3);
		
		    Cookie[] cookies = request.getCookies();
			out.print("firstName............."+cookies[0].getValue()+"<br><br>");
			out.print("lastName............."+cookies[1].getValue()+"<br><br>");
			out.print("address............."+cookies[2].getValue()+"<br><br>");
			out.close();
		
	}

}
