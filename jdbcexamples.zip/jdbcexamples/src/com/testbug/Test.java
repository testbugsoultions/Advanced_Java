package com.testbug;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
//		Class.forName("com.mysql.jdbc.Driver");
		try (
			Connection connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/department?characterEncoding=utf8", "root", "password");
			Statement statement = connection.createStatement();)
		{
			ResultSet rs = statement.executeQuery("select * from books");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3) + " " + rs.getInt(4));
			}
		}catch(Exception e)
	{
		e.printStackTrace();

	}

}
}