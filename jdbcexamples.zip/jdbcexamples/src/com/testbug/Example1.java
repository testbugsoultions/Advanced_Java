package com.testbug;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Example1 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		
//		Step:1 load the driver
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded compelted");
		
//		step:2 create the connecttion
      Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/products?characterEncoding=utf8", "root", "password");
      System.out.println("connection created sucessfully");
      
      
      //step:3 create the statment object
      Statement statement = connection.createStatement();
      
      
      // step:4 process the query
      // create the table query
    //  int count = statement.executeUpdate("create table  manager(mid varchar(225) ,mname varchar(225),msal varchar(225))");
      
      // insert queruy
   //   int count = statement.executeUpdate("insert into manager values(100,'prudhvi',7000)");
      
//      update the query
        
      int count = statement.executeUpdate("update manager set mname = 'anusha' where mid =100");
     
    //  System.out.println("table  created sucessfully");
      
   //   System.out.println("table  insert sucessfully"+count);
      
      System.out.println("table  updated sucessfully:"+count);
      
      // step:5 release resources
      
      connection.close();
      statement.close();
		
		
	}

}
