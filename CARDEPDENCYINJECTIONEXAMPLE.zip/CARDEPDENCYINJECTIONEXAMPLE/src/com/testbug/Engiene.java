package com.testbug;

// depenedent
public class Engiene {
	

	private int eid;
	private String ename;
	private String horsePower;
	
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getHorsePower() {
		return horsePower;
	}
	public void setHorsePower(String horsePower) {
		this.horsePower = horsePower;
	}
	
	@Override
	public String toString() {
		return "Engiene [eid=" + eid + ", ename=" + ename + ", horsePower=" + horsePower + "]";
	}
	

}
