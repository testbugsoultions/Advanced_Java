package com.testbug;

public interface ICar {
	
	public void drive();
	
	

}
