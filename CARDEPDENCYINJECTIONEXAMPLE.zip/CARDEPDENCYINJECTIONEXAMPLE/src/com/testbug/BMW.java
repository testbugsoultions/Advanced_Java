package com.testbug;

import java.util.List;

public class BMW implements ICar{
	
	private int bid;
	private String color;
	private String model;
	private List<String> wheels;
	private Engiene eng;
	
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public List<String> getWheels() {
		return wheels;
	}
	public void setWheels(List<String> wheels) {
		this.wheels = wheels;
	}
	public Engiene getEng() {
		return eng;
	}
	public void setEng(Engiene eng) {
		this.eng = eng;
	}
	
	@Override
	public void drive() {
	
		System.out.println("bid" +getBid());
		System.out.println("color" +getColor());
		System.out.println("model" +getModel());
		System.out.println("wheels" +getWheels());
		System.out.println("eng" +getEng());
		
	}

}
