package com.testbug;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("resources/springconfig.xml");
	
		ICar car = (ICar)ac.getBean("bmid");
		car.drive();
		
	}
	
	
	
}
