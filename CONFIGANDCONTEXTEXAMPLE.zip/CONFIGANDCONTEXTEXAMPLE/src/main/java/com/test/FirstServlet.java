package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  response.setContentType("text/html");  
		    PrintWriter out = response.getWriter();  
		    
		    
		    // servlet config 
		    
		    ServletConfig config=getServletConfig();  
		    out.println("this is the FirstServlet init param-1>>>>>>>>>>>"+config.getInitParameter("homeloan"));
		    out.println("this is the FirstServlet init param-2>>>>>>>>>>>"+config.getInitParameter("carloan"));
		
		    
		
		    // servlet context 
		    
		    
		    ServletContext servletContext = request.getServletContext();
		    out.println("this is the FirstServlet servletContext param-1>>>>>>>>>>>>>"+servletContext.getInitParameter("username"));
		    out.println("this is the FirstServlet servletContext param-2>>>>>>>>>>>>>>"+servletContext.getInitParameter("password"));

		
		
		
		
		
		
		
		
		
//		servelts
//		spring
//		springboot
		
//		Get-------------retrive the data
//		post -----------insert the data
//		put-------------update the data
//		delete---------delete the  data
		
		
		
		
		
		
		
	
	}


}
