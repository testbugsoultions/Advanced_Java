package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondServlet
 */
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    response.setContentType("text/html");  
		    PrintWriter out = response.getWriter();  
		      
		    ServletConfig config= this.getServletConfig();  
		    out.println("this is the SecondServlet init param 1>>>>>>>>>>>>>>"+config.getInitParameter("vcs1"));
		    out.println("this is the SecondServlet init param 2>>>>>>>>>>>>>>"+config.getInitParameter("vcs2"));
		
		    ServletContext servletContext = request.getServletContext();
		    out.println("this is the SecondServlet servletContext param 1>>>>>>>>>>>>>"+servletContext.getInitParameter("username"));
		    out.println("this is the SecondServlet servletContext param 2>>>>>>>>>>>>>>"+servletContext.getInitParameter("password"));

	}


}
