package com.tcs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FlipkartController {
	
	
	@Autowired
	private Furniture fc;
	
	@Autowired
	private Games gc;
	
	@Autowired
	private Refrigrator rc;
	
	
	public void show() {
		System.out.println("Purchaged by a Flipkart");
		fc.coat();
		gc.cricket();
		rc.ac();
		
		
	}
	
	
	

}
