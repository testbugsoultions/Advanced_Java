package com.tcs;

import org.springframework.stereotype.Component;

@Component
public class Furniture {

	public void coat() {
		
		System.out.println("This is Doublecoat");
		
	}
	
	
}
