package com.tcs;

import org.springframework.stereotype.Component;

@Component
public class Refrigrator {
	
	public void ac() {
		
		System.out.println("This is Daikin");
		
	}

}
