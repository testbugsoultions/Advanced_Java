package com.tcs;

import org.springframework.stereotype.Component;

@Component
public class Games {
	
public void cricket() {
		
		System.out.println("cricket need to Bats and Balls");
		
	}

}
