package com.operatores.examples;

public class OperatoresExample {
	
	public static void main(String[] args) {
		
	//	int i = 20;
	//	int j =6;
       // Arthametic Operator Examples		
//		System.out.println(i+j);
//		System.out.println(i-j);
//		System.out.println(i*j);
//		System.out.println(i/j);
//		System.out.println(i%j);
		
		// unary operators
		
//		System.out.println(i);
//		System.out.println(++i);
//		System.out.println(i++);
//		System.out.println(i);
//		System.out.println(i);   //20
//		System.out.println(--i); //19
//		System.out.println(i--); //19
//		System.out.println(i);//18
		
//	    Relational operators
//		
//		System.out.println(i==j);
//		System.out.println(i!=j);
//		System.out.println(i<j);
//		System.out.println(i>j);
//		System.out.println(i<=j);
//		System.out.println(i>=j);
		
//		conditianal operataors
		
//		System.out.println(i<j && i!=j);
//		System.out.println(i<j || i!=j);
		
		// Assignment operators
		
		int i = 20;
		int j = 6;
		
		//i = i+5;
	//	i += 5;
	//	i -= 5;
//		i *= 5;
//		i /= 5;
//		i %= 5;
		System.out.println(i);
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
