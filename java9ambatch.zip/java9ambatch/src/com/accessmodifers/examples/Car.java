package com.accessmodifers.examples;

public class Car {
	
	public static void main(String[] args) {
		
		Student  ss = new Student();
		System.err.println(ss.rollNumber);
		ss.printRollNumber();
		
		
	}
	

}
