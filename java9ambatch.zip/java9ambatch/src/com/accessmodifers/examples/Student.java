package com.accessmodifers.examples;

public class Student {
	
	protected int rollNumber = 101;
	
	
	protected Student() {
		rollNumber = 102;
		
	}
	
	protected void printRollNumber() {
		
		System.err.println(rollNumber);
	}
	
	public static void main(String[] args) {
		
		Student ss = new Student();
		System.out.println(ss.rollNumber);
		ss.printRollNumber();
	}

}
