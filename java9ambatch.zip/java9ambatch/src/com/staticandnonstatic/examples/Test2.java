package com.staticandnonstatic.examples;

public class Test2 {

	static {

		System.out.println("static block");

	}

	{

		System.out.println("non-static block");

	}

	public Test2() {

		System.out.println("constructer block");
	}

	public static void main(String[] args) {

		System.out.println("main-method");
		Test2  t1 =new Test2();
		Test2  t2 =new Test2();
		Test2  t3 =new Test2();
		Test2  t4 =new Test2();
		Test2  t5 =new Test2();
		Test2  t6 =new Test2();

	}
	
	
	

}
