package com.controllstatments.examples;

public class WhileExample {
	
	public static void main(String[] args) {
		
	//	int i =0;
//		while (i<10) {
//			System.out.println(i);
//			i++;
//		}
		
//		do {
//			System.out.println(i);
//			i++;
//		} while (i<0);
		
		
		int i;
		for( i =1;i<10;i++) {
			System.out.println(i);
			
		}
		System.out.println("excute serveral times"+i);
		
		
	}

}
