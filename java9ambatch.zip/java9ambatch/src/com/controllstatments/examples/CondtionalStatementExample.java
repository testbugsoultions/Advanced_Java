package com.controllstatments.examples;

public class CondtionalStatementExample {

	public static void main(String[] args) {

		String primils = "Pass";
		if (primils == "Pass") {
			System.out.println("You have clear the primils Please wait for the further rounds");

			String mains = "Pass";
			if (mains == "Pass") {
				System.out.println("you have to clear the mains Please wait for the further rounds");
				String interview = "Pass";
				if (interview == "Pass") {
					System.out.println("you have to clear the interview Please wait for results");
				} else {
					System.out.println("You have to go home");
				}
			} else {
				System.out.println("You have to go home");
			}

		} else {

			System.out.println("You have to go home");
		}

	}
}