package com.controllstatments.examples;

public class SwitchExample {

	public static void main(String[] args) {

		int i = 1;
		switch (i) {
		case 1:
          //  System.out.println("This is the first statment");
		//	break;
		case 2:
		    System.out.println("This is the second statment");
			break;
		case 3:
		    System.out.println("This is the third statment");
			break;
		case 4:
		    System.out.println("This is the fourth statment");
			break;
		default:
		    System.out.println("This is the default statment");
			break;
		}

	}

}
