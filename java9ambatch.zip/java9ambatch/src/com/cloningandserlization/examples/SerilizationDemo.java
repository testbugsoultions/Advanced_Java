package com.cloningandserlization.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable {

	int id;
	String name;

	public Student(int id, String name) {
		this.id = id;
		this.name = name;
	}

}

public class SerilizationDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Student s = new Student(100, "testbug");
		//serlization
	//	FileOutputStream fos = new FileOutputStream("D:\\solutions\\resume.txt");
	//	ObjectOutputStream ous = new ObjectOutputStream(fos);
	//	ous.writeObject(s);
	//	fos.close();
	//	ous.close();
		// deserlization
		FileInputStream fis = new FileInputStream("D:\\solutions\\resume.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Student object = (Student)ois.readObject();
		System.out.println(object.id+" "+object.name);
		fis.close();
		ois.close();

	}

}
