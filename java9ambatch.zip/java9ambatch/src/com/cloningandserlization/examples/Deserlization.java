package com.cloningandserlization.examples;

public class Deserlization {

}
