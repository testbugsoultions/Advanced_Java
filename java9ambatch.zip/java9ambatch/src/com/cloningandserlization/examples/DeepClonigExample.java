package com.cloningandserlization.examples;
class Departments implements Cloneable{
    String empId;
    String grade;
    String designation;
    public Departments(String empId, String grade, String designation) {
        this.empId = empId;
        this.grade = grade;
        this.designation = designation;
    }
    //Default version of clone() method.
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
class Employees implements Cloneable {
    int id;
    String name;
    Departments dept;
 
    public Employees(int id, String name, Departments dept) {
        this.id = id;
        this.name = name;
        this.dept = dept;
    }
    @Override
    protected Object clone() throws CloneNotSupportedException {
    	Employees emp = (Employees)super.clone();
    	  emp.dept = (Departments)dept.clone();
    	  return emp;
    }
}
public class DeepClonigExample {
	
	public static void main(String[] args) {
		Departments dept1 = new Departments("1", "A", "AVP");
		Employees emp1 = new Employees(111, "John", dept1);
		Employees emp2 = null;
	        try {
	            emp2 = (Employees) emp1.clone();
	        } catch (CloneNotSupportedException e) {
	            e.printStackTrace();
	        }
	 
	        System.out.println(emp1.dept.designation); // Output : AVP
	        emp2.dept.designation = "Manager";
	        System.out.println(emp1.dept.designation); // Output : AVP
		
	}

}
