//package com.arrays.examples;
//
//import com.accessmodifers.examples.Student;
//
//public class Sample {
//	
//	public static void main(String[] args) {
//		
//		Student  ss = new Student();
//		System.err.println(ss.rollNumber);
//		ss.printRollNumber();
//		
//		
//		
//	}
//
//}
