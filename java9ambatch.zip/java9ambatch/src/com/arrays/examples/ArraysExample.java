package com.arrays.examples;

public class ArraysExample {
	
	public static void main(String[] args) {
		
		int [] arr = new int[3];
		arr[0] =5;
		arr[2] =34;
		arr[1] =66;
		
		//System.out.println(arr[2]);
		
//		for(int i =0;i<arr.length;i++) {
//			
//			System.out.println(arr[i]);
//		}
		int i=0;
		while (i<arr.length) {
			System.out.println(arr[i]);
			i++;
		}
		
		
		
	}

}
