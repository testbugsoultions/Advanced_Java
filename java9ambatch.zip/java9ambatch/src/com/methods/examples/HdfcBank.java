package com.methods.examples;

public class HdfcBank {

//	accessmodifer staticornonstatic returntypemethodname(parameters)throwsExcepionList{
//		method body
	// return value
//	}
   static   int balance = 1000;
	public static void greetings() {
		System.out.println("welcome to the HDFC BANK ");
	}
	public void deposit(int amount) {
		balance = balance+amount;
		System.out.println("Amount deposit succesfully");
	}
	
	public static void withdraw(int amount) {
		balance = balance-amount;
		System.out.println("Amount withdraw succesfully");
	}
	
	public int getCurrentBalance() {
		
		return balance;
	}
	
	public static void main(String[] args) {
		HdfcBank hd = new HdfcBank();
		greetings();
		System.out.println("current balance"+hd.getCurrentBalance());
		hd.deposit(500);
		System.out.println("current balance"+hd.getCurrentBalance());
		hd.withdraw(300);
		System.out.println("current balance"+hd.getCurrentBalance());
		
		
		
		
		
		
	}

}
