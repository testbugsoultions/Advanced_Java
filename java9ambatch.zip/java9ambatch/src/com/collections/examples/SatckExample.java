package com.collections.examples;

import java.util.Stack;

public class SatckExample {
	
	public static void main(String[] args) {
		
		Stack<String> stk= new Stack<>();  
		stk.push("Mac Book");  
		stk.push("HP");  
		stk.push("DELL");  
		stk.push("Asus");  
		System.out.println("Stack: " + stk);  
		// Search an element  
		int location = stk.search("HP");  
		System.out.println(location);
		
	}

}
