package com.collections.examples;

import java.util.*;

public class VectorExample {
	
	public static void main(String[] args) {
		
//		
//		int [] arr = new int[6];
//		arr[0] =10;
//		arr[1] =20;
//		arr[2] =30;
//		arr[3] =40;
//		arr[4] =50;
//		arr[5] =60;
//		
//		System.out.println(arr[5]);
		
		
		
		
		Vector v = new Vector();  // synchronized leagcy
		
	    v.add("apple");
	    v.add("grapes");
	    v.add("orange");
	    v.add("baanna");
	    v.add("hello");
	    v.add(0, "anusha");
	    v.addLast("vali");
	    
	    System.out.println(v);
	    
       Object obj = new Object[] {1,2,3,4,5};
		
		Vector v1 = new Vector<>(Arrays.asList(obj));
		v1.add("hello");
		
		int size =0;
		
		for(int i =0;i<v1.size();i++) {
			size += (Integer)v1.get(i);
		}
		
		System.out.println(v1);
		
	}

		
		
	}

