package com.collections.examples;

import java.util.ListIterator;
import java.util.Vector;

public class EnumerationExample {
	public static void main(String[] args) {

		Vector<Integer> v = new Vector<Integer>();
		v.add(10);
		v.add(20);
		v.add(30);
		v.add(40);
		v.add(50);

		System.out.println(v);
//		
//		Enumeration<Integer> elements = v.elements();
//		
//		while (elements.hasMoreElements()) { 
//            int i = (Integer)elements.nextElement(); 
//              
//            System.out.print(i + " "); 
//        }
		  // Creating Iterator object 
//        Iterator<Integer> itr = v.iterator(); 
//          
//        while (itr.hasNext()) { 
//            int i = (Integer)itr.next(); 
//            if (i == 10) 
//                itr.remove(); 
//        } 
//        System.out.println(v); 
//        System.out.println(); 
        
        System.out.println("ListIterator: "); 
        
        // Creating ListIterator object 
        ListIterator<Integer> ltr = v.listIterator(); 
          
        // Checking the next element availability 
        while (ltr.hasNext()) { 
              
            // Moving cursor to the next element 
            int i = (Integer)ltr.next(); 
              
            // Performing add, remove, and  
            // replace operation 
            if (i == 20) 
                ltr.remove(); 
              
            else if (i == 30) 
                ltr.add(60); 
              
            else if (i == 40) 
                ltr.set(100); 
        } 
          
        System.out.println(v); 
    } 
          
	}
