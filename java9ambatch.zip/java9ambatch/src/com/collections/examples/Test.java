package com.collections.examples;

import java.util.Arrays;
import java.util.Vector;

public class Test {
	
	public static void main(String[] args) {
		
		Object obj = new Object[] {1,2,3,4,5};
		
		Vector v1 = new Vector<>(Arrays.asList(obj));
		v1.add("hello");
		
		int size =0;
		
		for(int i =0;i<v1.size();i++) {
			size += (Integer)v1.get(i);
		}
		
		System.out.println(v1);
		
	}

}
