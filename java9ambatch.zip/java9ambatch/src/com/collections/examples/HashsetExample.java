package com.collections.examples;

import java.util.HashSet;

public class HashsetExample {

	public static void main(String[] args) {

		HashSet<String> set = new HashSet();
		set.add("One");
		set.add("Two");
		set.add("One");
		set.add("Four");
		set.add("Five");
		set.add("Four");
		System.out.println(set);
	}

}
