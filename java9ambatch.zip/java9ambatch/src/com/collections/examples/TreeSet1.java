package com.collections.examples;

import java.util.TreeSet;

public class TreeSet1 {

	public static void main(String[] args) {

		TreeSet<String> al = new TreeSet<String>();
		al.add("Ravi");
		al.add("Vijay");
		al.add("Test");
		al.add("Ajay");
		al.add("Test");
		System.err.println(al);
	}
}
