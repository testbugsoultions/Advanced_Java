package com.collections.examples;

import java.util.LinkedList;

public class LinkedListExample {
	
	public static void main(String[] args) {
		
		 LinkedList<String> al=new LinkedList<String>();  
		  al.add("Bala");  
		  al.add("testbug");  
		  al.add("soultions");  
		  al.add("Ajay");  
		  System.out.println(al);
		  al.remove(1);
		  System.out.println(al);
		
		
	}

}
