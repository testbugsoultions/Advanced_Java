package com.collections.examples;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapExample {
	
	public static void main(String[] args) {
		
		Map<Integer, String>  hm = new HashMap<>();
		
		hm.put(1, "Apple");
		hm.put(2, "Orange");
		hm.put(3, "Grapes");
		hm.put(4, "Banaana");
		hm.put(1, "Orange");
		System.out.println(hm);
		hm.put(104,"Ravi");  
		System.out.println(hm);
		hm.remove(104);
		System.err.println(hm);
		
//		       Set<Integer> keySet = hm.keySet();
//		      System.out.println(keySet);
//		          
//		      Collection<String> values = hm.values();
//		      
//		      System.err.println(values);
//		
//		 for(Map.Entry m :hm.entrySet()) {
//			 
//			 System.out.println(hm.keySet()+" "+hm.values());
//		 }
////		
		
		
		
		
	}

}
