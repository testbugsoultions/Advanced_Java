package com.collections.examples;

import java.util.ArrayList;

public class ArrayListExample {
	public static void main(String[] args) {

		ArrayList<String> list1 = new ArrayList<String>();
		list1.add("Ravi");
		list1.add("Vijay");
		list1.add("Ajay");
		list1.add("Vijay");
		list1.add("Vijay");
		System.err.println(list1);
		for (String s : list1) {

			System.out.println(s);
		}

//		ArrayList<Integer> list2 =new ArrayList<Integer>();
//		list2.add(1);  
//		list2.add(2);  
//		list2.add(3); 
//		list2.add(4);  
//		list2.add(5); 
//		System.out.println(list2);

		// ArrayList list2 =new ArrayList();
		// list2.add("Sonoo");
		// list2.add("Hanumat");
		// System.out.println(list.contains("orange"));
		// list.set(0, "vali");
		// list.remove(2);
		// System.out.println(list.containsAll(list2));
		// list1.addAll(list2);
		// list2.removeAll(list2);
		// System.out.println(list2);

	}

}
