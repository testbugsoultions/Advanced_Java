package com.encapsulationdemo.examples;

public class EncapsulationDemo1 {
	
	private String name;
	
	public String getName() {
		
		return name;
	}
	
	
	public void setName(String name) {
		
		this.name=name;
	}
	
	
	

}
