package com.encapsulationdemo.examples;

public class EncapsulatoionDemo2 {
	
	
	public static void main(String[] args) {
		
		EncapsulationDemo1 ed = new EncapsulationDemo1();
		ed.setName("soultions");
		System.out.println(ed.getName());
		
	}

}
