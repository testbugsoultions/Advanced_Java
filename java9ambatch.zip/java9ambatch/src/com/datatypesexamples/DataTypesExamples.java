package com.datatypesexamples;

public class DataTypesExamples {
	
	public static void main(String[] args) {
		
		byte b =10;
		short s = 40;
		int i =90;
		long l= 9765675765L;
		float f=3.16f;
		double d = 88.789;
		boolean b1 = false;
		char c = 'a';
		
	//	System.out.println(Byte.SIZE/8);
		
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		
		
	}

}
