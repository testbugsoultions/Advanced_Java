package com.inheritence.examples;

import com.accessmodifers.examples.Student;

public class Subclass extends Student{
	
	public static void main(String[] args) {
		
		new Subclass().test();
		
	}
	
	
	public void test() {
		System.err.println(rollNumber);
		printRollNumber();
		
	}
	

}
