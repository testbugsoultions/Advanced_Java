package com.testbug.stringsexamples;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
	  StringBuilder sb1 = new StringBuilder("Testbug");//27 // mutable change the value
	  StringBuilder sb2 = new StringBuilder("Testbug");//40//37
	  StringBuilder sb3 = new StringBuilder();
	 
	  
	//  sb1.append("solutions");//27
	  
	//  sb1.insert(3, "hello");
	  
	//  sb1.reverse();
	  
	 // sb1.capacity();
	//  sb1.delete(3, 6);
	//  System.out.println(sb1);
	  
	 // StringBuffer sb = new StringBuffer();
	  
	// System.out.println(sb3.capacity());
	  
	
	  
	  
	  
	

	}

}
