package com.testbug.exceptionhandling;

public class LoginException extends Exception{
	
	
	 public LoginException(String message) {
	        super(message);
	    }

}
