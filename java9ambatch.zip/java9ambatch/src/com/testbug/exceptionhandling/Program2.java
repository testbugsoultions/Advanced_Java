package com.testbug.exceptionhandling;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Program2 {
	
	public static void main(String[] args) throws IOException {
		
		
		
		File fi = new File("./sample.txt");
		if(!fi.exists())
			System.out.println(fi.createNewFile());
		
		FileOutputStream fos = new FileOutputStream(fi);
		String s = "Good Morning";
		
		for (char ch : s.toCharArray()) {
			
			fos.write((int)ch);
		}
		
		
		
		
	}
	
	

}
