package com.testbug.exceptionhandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Prgram1 {
	
	public static void main(String[] args) throws IOException {
		
		File fi = new File("./sample.txt");
		if(!fi.exists())
			System.out.println(fi.createNewFile());
		
		Scanner sc = new Scanner(fi);
		
		while(sc.hasNext()) {
			
			System.out.print(sc.nextLine());
			
		}
		
		
//			
//		FileInputStream fis = new FileInputStream(fi);
//		
//		int asc;
//		
//		while((asc = fis.read())!= -1) {
//		
//		System.out.print((char)asc);
//		}
	}

}
