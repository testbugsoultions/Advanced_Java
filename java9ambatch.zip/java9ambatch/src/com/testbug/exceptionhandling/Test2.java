package com.testbug.exceptionhandling;

public class Test2 {

	public static void main(String[] args) throws LoginException {

		try {

		System.out.println(20/0);

		} catch (ArithmeticException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage());
			System.out.println(e.toString());
		//	throw new LoginException("dont devide the zero");
	
		}

	}

}
