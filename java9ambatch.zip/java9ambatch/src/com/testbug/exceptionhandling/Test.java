package com.testbug.exceptionhandling;

public class Test {

	public static void main(String[] args) {

		try {
			// code that may raise exception
		//	int data = 100 / 0;
			//String s=null;  
		//	System.out.println(s.length());
			int[]  arr = {1,2};  
			System.out.println(arr[3]);
		} catch (ArrayIndexOutOfBoundsException e1) {
			System.out.println(e1);
		} catch (NullPointerException e2) {
			System.out.println(e2);
		}catch (ArithmeticException   e3) {
			System.out.println(e3);
		}
		System.out.println("rest of the code...");
	}

}
