package com.multithreading.examples;

public class Test {
	
	public static void main(String[] args) throws InterruptedException {
		Runnable r1 =()->{
			for(int i=0;i<5;i++) {
				//System.out.println("Hello: "+Thread.currentThread().getName()+">>>>>>"+Thread.currentThread().getId());
			}
		};
		Runnable r2 =()->{
			for(int i=0;i<10;i++) {
				//System.out.println("Hai: "+Thread.currentThread().getName()+">>>>>>"+Thread.currentThread().getId());
			}
		};
		
		Thread t1 = new  Thread(r1,"T1");
		Thread t2 = new  Thread(r2,"T1");
		System.err.println(t1.getState());
		
		t1.start();
		System.err.println(t1.getState());
		t1.sleep(10000);
//		t1.join();
		t2.start();
		System.err.println(t1.getState());
		
		
		
	}

}
