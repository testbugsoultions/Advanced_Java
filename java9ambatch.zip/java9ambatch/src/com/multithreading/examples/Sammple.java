package com.multithreading.examples;

class Hello {

 synchronized	void prinTable(int n) {
		for (int i = 1; i <= 5; i++) {
			System.out.println(n * i);
			try {
				Thread.sleep(400);
			} catch (Exception e) {
			System.err.println(e);
			}
		}
	}
}

class Thread1 extends Thread {

	Hello t;

	public Thread1(Hello t) {
		this.t = t;
	}

	public void run() {
		t.prinTable(5);
	}

}

class Thread2 extends Thread {

	Hello t;

	public Thread2(Hello t) {
		this.t = t;
	}

	public void run() {
		t.prinTable(100);
	}

}

class Sammple {
	public static void main(String[] args) {
		Hello h = new Hello();
		Thread1 t1 = new Thread1(h);
		Thread2 t2 = new Thread2(h);
		t1.start();
		t2.start();

	}
}