package com.testbug;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfigFile {
	
	
    @Bean
	public Employee emp1() {
		Employee e = new Employee();
		e.setId(1);
		e.setName("prudhvi");
		e.setEmail("abc@gmail.com");
		return e;
	}

}
