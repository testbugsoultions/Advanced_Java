package com.testbug.soultions;

import java.util.List;

public class BMWImp implements ICar{


	private int id;
	private String color;
	private String model;
	private Engine engine;
	private List<String>  wheels;
	
	@Override
	public void drive() {
		
		System.out.println("BMW details below");
		System.out.println("BMW id:"+getId());
		System.out.println("BMW color:"+getColor());
		System.out.println("BMW model:" +getModel());
		System.out.println("BMW details:"+getEngine());
		System.out.println("BMW details:"+getWheels());
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public List<String> getWheels() {
		return wheels;
	}

	public void setWheels(List<String> wheels) {
		this.wheels = wheels;
	}
	
	
	
	
	
	
}
