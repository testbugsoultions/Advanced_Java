package com.testbug.soultions;

public class Engine {
	
	private int engine_Id;
	private String engine_Name;
	private String hourse_Power;
	
	@Override
	public String toString() {
		return "Engine [engine_Id=" + engine_Id + ", engine_Name=" + engine_Name + ", hourse_Power=" + hourse_Power
				+ "]";
	}
	public int getEngine_Id() {
		return engine_Id;
	}
	public void setEngine_Id(int engine_Id) {
		this.engine_Id = engine_Id;
	}
	public String getEngine_Name() {
		return engine_Name;
	}
	public void setEngine_Name(String engine_Name) {
		this.engine_Name = engine_Name;
	}
	public String getHourse_Power() {
		return hourse_Power;
	}
	public void setHourse_Power(String hourse_Power) {
		this.hourse_Power = hourse_Power;
	}
		
	
	

}
