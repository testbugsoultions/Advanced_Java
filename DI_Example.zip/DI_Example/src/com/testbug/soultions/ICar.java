package com.testbug.soultions;

public interface ICar {
	
	void drive();

}
