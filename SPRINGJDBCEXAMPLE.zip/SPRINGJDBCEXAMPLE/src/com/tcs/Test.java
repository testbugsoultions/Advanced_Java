package com.tcs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	public static void main(String[] args) {
		
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("resources/config.xml");
		
		StudentDao st = (StudentDao)ac.getBean("estd");
		
//	    int saveStudent = st.saveStudent(new Student(102,"Amit",35000));
//	   
//	    System.out.println(saveStudent);
////	
	    
	    int updateStudent = st.updateStudent(new Student(102,"kcr",80));
	    
	    System.out.println(updateStudent);
	    
	}
	
	

}
