package com.tcs;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao {
	
	private JdbcTemplate jdbcTemplate;  
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	
//	
//	public int saveStudent(Student ss) {
//		String query1 = "insert into student values('"+ss.getId()+"','"+ss.getName()+"','"+ss.getAge()+"')";  
//		return jdbcTemplate.update(query1);
//	}
	
	public int updateStudent(Student ss){
		
	String query2="update student set name='"+ss.getName()+"',age='"+ss.getAge()+"'where id='"+ss.getId()+"' ";  
		
		return jdbcTemplate.update(query2);   
		
		
	}
	
	
	
	
	
	
	
	

}
