package com.testbug;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
public class FirstServlet implements Servlet{

	public void destroy() {
		System.out.println("This is a destroy method ");
		
	}

	public ServletConfig getServletConfig() {
		System.out.println("This is a getServletConfig method ");

		return null;
	}

	public String getServletInfo() {
		System.out.println("This is a getServletInfo method ");

		return null;
	}

	public void init(ServletConfig arg0) throws ServletException {
		System.out.println("This is a init method ");

		
	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("This is a service method ");
		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();
		writer.println("This is the Servlet First Application Example");
		
		
	}


	
}
