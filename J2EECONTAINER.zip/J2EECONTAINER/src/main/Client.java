package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Test;

public class Client {
	
	public static void main(String[] args) {
		
	ApplicationContext ac = new ClassPathXmlApplicationContext("resources/springconfig.xml");
	Test bean1 = (Test)ac.getBean("eid");
	Test bean2 = (Test)ac.getBean("eid");
	Test bean3 = (Test)ac.getBean("eid");
	Test bean4 = (Test)ac.getBean("eid");
	
	bean1.hello();
	bean2.hello();
	bean3.hello();
	bean4.hello();
	
	System.out.println(bean1 == bean2);
	System.out.println(bean3 == bean4);
		
		
	}

}
