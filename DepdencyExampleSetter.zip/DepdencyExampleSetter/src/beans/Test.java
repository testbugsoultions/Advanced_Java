package beans;

public class Test {
	
	private String gender;


	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	public void data() {
		
		System.out.println("Mr:"+ gender);
	}

	
	
}
